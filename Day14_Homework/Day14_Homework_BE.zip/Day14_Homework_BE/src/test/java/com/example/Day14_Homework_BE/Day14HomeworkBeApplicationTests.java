package com.example.Day14_Homework_BE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day14HomeworkBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
