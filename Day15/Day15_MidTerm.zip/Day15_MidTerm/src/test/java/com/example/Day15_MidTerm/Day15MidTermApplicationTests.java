package com.example.Day15_MidTerm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day15MidTermApplicationTests {

	@Test
	void contextLoads() {
	}

}
