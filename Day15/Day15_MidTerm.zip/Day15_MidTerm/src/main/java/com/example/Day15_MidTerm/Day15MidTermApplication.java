package com.example.Day15_MidTerm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day15MidTermApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day15MidTermApplication.class, args);
	}

}
