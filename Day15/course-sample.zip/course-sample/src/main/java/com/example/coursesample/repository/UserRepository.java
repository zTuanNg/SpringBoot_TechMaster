package com.example.coursesample.repository;

import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {
}
