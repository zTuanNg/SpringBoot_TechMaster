package com.example.Day09Homework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day09HomeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
