package com.example.Day09Homework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day09HomeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day09HomeworkApplication.class, args);
	}

}
