package vn.techmaster.bookstore.request;

public class SearchRequest {
  private String keyword;

  public String getKeyword() {
    return keyword;
  }

  public void setKeyword(String keyword) {
    this.keyword = keyword;
  }
}
